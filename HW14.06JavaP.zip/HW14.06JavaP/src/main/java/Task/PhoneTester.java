package Task;

public class PhoneTester {
    public static void main(String[] args) {

        Phone samsung = new Phone();
        samsung.number = 160456789; //значения экземпляра
        samsung.model = "Galaxy";
        samsung.weight = 134;

        Phone iphone = new Phone();
        iphone.number = 172456879;
        iphone.model = "IPhone14 Pro";
        iphone.weight = 165;

        Phone sony = new Phone();
        sony.number = 176989625;
        sony.model = "Z1";
        sony.weight = 205;

        System.out.println(samsung.number + " Номер телефона");
        System.out.println(samsung.model + " Модель телефона");
        System.out.println(samsung.weight + " вес телефона");
        System.out.println();
        System.out.println(iphone.number + " Номер телефона");
        System.out.println(iphone.model + " Модель телефона");
        System.out.println(iphone.weight + " вес телефона");
        System.out.println();
        System.out.println(sony.number + " Номер телефона");
        System.out.println(sony.model + " Модель телефона");
        System.out.println(sony.weight + " вес телефона");

        samsung.receiveCall("samsung");
        samsung.getNumber();
        iphone.receiveCall("iphone");
        iphone.getNumber();
        sony.receiveCall("sony");
        sony.getNumber();
    }
}
