package Task;

public class PersonTester {


        public static void main(String[] args) {
            Person Ant = new Person();
            Ant.setFullName("Ant");
            Ant.setAge(45);

            Person Kant = new Person("Kant", 40);
            Ant.talk();
            Kant.move();
        }



}
