package Task;
// 1 уровень сложности: 1. Создать класс Person, который содержит:
//переменные fullName, age;
//методы move() и talk(), в которых просто вывести на консоль сообщение - "Person {такой-то} говорит" и
//"Person {такой-то} идет" (замените {такой-то} на fullName).
//Добавьте геттеры и сеттеры.
//Добавьте два конструктора  - Person() и Person(fullName, age).
//Создайте два объекта этого класса. Один объект инициализируйте конструктором Person() и сеттерами, другой - конструктором Person(fullName, age)
public class Person {

    String fullName;
    int age;

    public void move() {
        System.out.println("Person " + fullName + " идет");
    }
    public void talk() {
        System.out.println("Person " + fullName + " говорит");
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Person() {
    }

    public Person(String fullName, int age) {
        this.fullName = fullName;
        this.age = age;
    }


}
